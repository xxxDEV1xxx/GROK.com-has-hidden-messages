;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="add5c52e-4906-9ba1-ae0b-b5f3c6b6ebed")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,4255400,8372116,e=>{"use strict";var t=e.i(25464),a=e.i(2460512),r=e.i(458272);e.i(379120);var n=e.i(8430260),o=e.i(9019178),i=e.i(3530307),s=e.i(2038207),l=e.i(860185),c=e.i(8502391),u=e.i(2777665),d=e.i(6307696),h=e.i(9136702),f=e.i(2123557),p=e.i(9301014),m=e.i(6190807),g=e.i(2569170),v=e.i(2730497);function b(e){let t=(0,v.deriveSharedResponseFromChunks)(e);return t?{...e,message:t.message,generatedImageUrls:t.generatedImageUrls,cardAttachmentsJson:t.cardAttachmentsJson}:e}async function x(e,t=g.chatApi,a){let r=await t.chatGetShareLink({shareLinkId:e,useChunk:!0},{headers:a});if(!r.conversation)throw Error("Conversation not found.");if(!r.responses||0===r.responses.length)throw Error("No responses in conversation.");let n={...r.conversation};return{responses:r.responses.map(e=>({...b(e),conversationId:n.conversationId,state:"closed"})),conversation:n}}e.s(["fetchEnrichedSharedChat",0,x,"projectChunksOntoFlatFields",0,b],8372116);var y=e.i(8043106),w=e.i(572671),S=e.i(603814),A=e.i(3710507),k=e.i(7671246),C=e.i(419746),R=e.i(9900502);e.i(3778443);var P=e.i(2830736),_=e.i(8501781),I=e.i(8633562);e.i(1354374);var D=e.i(352006),L=e.i(5615448),E=e.i(8265611);let T="HcydF4kDI5";function M(e){return e?.canUseDebugTools===!0}let N=(0,c.createSessionStore)();function j(){let e,t=(0,a.c)(2),r=(0,I.use)(c.SessionStoreContext)??N,n=(0,E.useStore)(r,F);return t[0]!==n?(e=M(n),t[0]=n,t[1]=e):e=t[1],e}function F(e){return e.user}async function B({type:e,params:t}){let a=new URLSearchParams({type:e});Object.entries(t).forEach(([e,t])=>{t&&a.set(e,t)});let r=await (0,w.fetch)(`/api/debug-links?${a.toString()}`,{cache:"no-store"});if(!r.ok)throw Error(`Failed to get debug link: ${r.status}`);let n=await r.json();if(!n.url)throw Error("Debug link response missing URL");return n.url}function z(e){let t=window.open("about:blank","_blank");t?(t.opener=null,B(e).then(e=>{t.location.href=e}).catch(e=>{t.close(),(0,S.logError)("debug-menu:openDebugLink",e),L.toast.error("Failed to open debug link")})):L.toast.error("Failed to open debug link")}function U(){let e=j(),[t]=(0,m.useLocalStorage)(T,!1);return!!e&&!t}function O(e,t){return!!e||"workspace"===t.page&&!!t.conversationId}function V(){let e,t=(0,a.c)(3),{isChatPage:r}=(0,f.useGrokRouter)(),{route:n}=(0,A.useRouting)();return t[0]!==r||t[1]!==n?(e=O(r,n),t[0]=r,t[1]=n,t[2]=e):e=t[2],e}function G(e){return e.conversationId}function H(e){return e.lastMessageId}function q(e){let r,i,s,l,c,u,d,h,f,p=(0,a.c)(19),{conversationId:m,className:g}=e;return p[0]!==g?(r=(0,k.cn)("flex items-center gap-1.5 text-xs font-normal text-secondary",g),p[0]=g,p[1]=r):r=p[1],p[2]!==m?(i=()=>{navigator.clipboard.writeText(m).then(X).catch(Y)},s=(0,t.jsx)("span",{className:"truncate",children:m}),p[2]=m,p[3]=i,p[4]=s):(i=p[3],s=p[4]),p[5]===Symbol.for("react.memo_cache_sentinel")?(l=(0,t.jsx)(n.CopyIcon,{size:12,className:"shrink-0"}),p[5]=l):l=p[5],p[6]!==m||p[7]!==i||p[8]!==s?(c=(0,t.jsxs)("button",{type:"button",className:"flex min-w-0 items-center gap-1 hover:text-fg-primary",title:m,onClick:i,children:[s,l]}),p[6]=m,p[7]=i,p[8]=s,p[9]=c):c=p[9],p[10]!==m?(u=()=>z({type:"trace",params:{conversationId:m}}),p[10]=m,p[11]=u):u=p[11],p[12]===Symbol.for("react.memo_cache_sentinel")?(d=(0,t.jsx)(o.SquareArrowOutUpRightIcon,{size:12}),p[12]=d):d=p[12],p[13]!==u?(h=(0,t.jsxs)("button",{type:"button",className:"flex shrink-0 items-center gap-0.5 hover:text-fg-primary",onClick:u,children:["trace",d]}),p[13]=u,p[14]=h):h=p[14],p[15]!==r||p[16]!==c||p[17]!==h?(f=(0,t.jsxs)("span",{className:r,children:[c,h]}),p[15]=r,p[16]=c,p[17]=h,p[18]=f):f=p[18],f}function Y(){return L.toast.error("Failed to copy conversation id to clipboard")}function X(){return L.toast.success("Copied conversation id to clipboard")}function K(e){let r,n,o,i,s=(0,a.c)(6),{shareLinkId:l}=e;s[0]!==l?(r={queryKey:["share",l],queryFn:()=>x(l,g.chatApi)},s[0]=l,s[1]=r):r=s[1];let{data:c}=(0,P.useQuery)(r);return c?(s[2]===Symbol.for("react.memo_cache_sentinel")?(n=(0,k.cn)("text-secondary font-normal text-xs","flex flex-row gap-1 items-center"),o=(0,t.jsx)("span",{children:"convo id: "}),s[2]=n,s[3]=o):(n=s[2],o=s[3]),s[4]!==c.conversation.conversationId?(i=(0,t.jsxs)("div",{className:n,children:[o,(0,t.jsx)(q,{conversationId:c.conversation.conversationId})]}),s[4]=c.conversation.conversationId,s[5]=i):i=s[5],i):null}function W(e){let n,o,i,s,l,c=(0,a.c)(10),{shareLinkId:u}=e,d=(0,r.useChatPageStore)(J);c[0]!==d?(n=e=>d?e.byId[d]?.teamId:void 0,c[0]=d,c[1]=n):n=c[1];let h=(0,C.useConversationStore)(n);c[2]!==u?(o=["share",u],i=()=>x(u,g.chatApi),c[2]=u,c[3]=o,c[4]=i):(o=c[3],i=c[4]);let f=!!u;c[5]!==o||c[6]!==i||c[7]!==f?(s={queryKey:o,queryFn:i,enabled:f},c[5]=o,c[6]=i,c[7]=f,c[8]=s):s=c[8];let{data:p}=(0,P.useQuery)(s);return(u?p?.conversation.teamId:h)?(c[9]===Symbol.for("react.memo_cache_sentinel")?(l=(0,t.jsx)("span",{className:(0,k.cn)("px-1.5 py-0.5 rounded text-[10px] font-semibold leading-none","bg-blue-500/20 text-blue-400 border border-blue-500/30"),children:"Grok Business"}),c[9]=l):l=c[9],l):null}function J(e){return e.conversationId}function $(){let e,n,o=(0,a.c)(4),i=(0,r.useChatPageStore)(Z),s=(0,R.useResponseStore)(Q);return o[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,k.cn)("text-secondary hover:text-fg-primary","font-normal"),o[0]=e):e=o[0],o[1]!==s||o[2]!==i?(n=(0,t.jsx)(u.Button,{className:e,variant:"none",size:"none",onClick:()=>{var e=i,t=s;let a=new Blob([ed(e,t)??JSON.stringify({message:"No data to show"})],{type:"application/json"});if(a){let e=window.URL.createObjectURL(a);window.open(e,"_blank")}},children:"export"}),o[1]=s,o[2]=i,o[3]=n):n=o[3],n}function Q(e){return e.byId}function Z(e){return e.lastMessageId}function ee(){let e,n,o=(0,a.c)(3),i=(0,r.useChatPageStore)(et);return i?(o[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,k.cn)("text-secondary hover:text-fg-primary","font-normal"),o[0]=e):e=o[0],o[1]!==i?(n=(0,t.jsx)(u.Button,{className:e,variant:"none",size:"none",onClick:()=>{z({type:"trace",params:{conversationId:i}})},children:"trace"}),o[1]=i,o[2]=n):n=o[2],n):null}function et(e){return e.conversationId}function ea(){let e,n,o=(0,a.c)(4),i=(0,r.useChatPageStore)(en),s=(0,r.useChatPageStore)(er);return i?(o[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,k.cn)("text-secondary hover:text-fg-primary","font-normal"),o[0]=e):e=o[0],o[1]!==i||o[2]!==s?(n=(0,t.jsx)(u.Button,{className:e,variant:"none",size:"none",onClick:()=>{z({type:"admin-inspect",params:{conversationId:i,responseId:s}})},children:"inspect"}),o[1]=i,o[2]=s,o[3]=n):n=o[3],n):null}function er(e){return e.lastMessageId}function en(e){return e.conversationId}function eo(){let e,n,o=(0,a.c)(3),i=(0,r.useChatPageStore)(ei);return i?(o[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,k.cn)("text-secondary hover:text-fg-primary","font-normal"),o[0]=e):e=o[0],o[1]!==i?(n=(0,t.jsx)(u.Button,{className:e,variant:"none",size:"none",onClick:()=>{z({type:"terminal-artifacts",params:{conversationId:i}})},children:"artifacts"}),o[1]=i,o[2]=n):n=o[2],n):null}function ei(e){return e.conversationId}function es(e){let a=e.debugLink;return(0,t.jsxs)("div",{className:"flex flex-row gap-1",children:[(0,t.jsxs)("span",{className:"text-secondary",children:[e.label,": "]}),a?(0,t.jsx)("button",{type:"button",onClick:()=>z(a),className:(0,k.cn)("block underline cursor-pointer","text-fg-primary hover:text-primary"),children:e.value}):(0,t.jsx)("span",{className:"block",children:e.value})]},e.label)}function el(e){return e.value}function ec(e){return e.currentVoiceSessionId}function eu(e){return e.livekitRequestId}function ed(e,t){if((0,c.getSessionStoreState)()?.getState().user?.canUseDebugTools!==!0)return void console.error("Debug export is not available for this session");if(!e)return void console.error("No last message id");let a=t[e];return a?JSON.stringify((0,y.getAncestorIds)(a,t).map(e=>t[e]).filter(e=>void 0!==e).map(e=>({role:"human"===e.sender?"user":"assistant",content:e.message,...(0,_.pick)(e,"thinkingTrace","steps","generatedImageUrls","metadata")})),null,2):void console.error("No response for last message id",e)}e.s(["DEBUG_STORAGE_KEY",0,T,"DebugConversationLinks",0,q,"DebugLivekit",0,function(e){let o,i,s,l,c=(0,a.c)(12),{className:u}=e,d=U(),h=(0,r.useChatPageStore)(eu),f=(0,r.useChatPageStore)(ec),p=h||f,m=h?"Livekit request id":"Voice session id";return d&&p?(c[0]!==u?(o=(0,k.cn)("text-red-400 font-normal text-xs flex flex-row gap-3 justify-center items-center",u),c[0]=u,c[1]=o):o=c[1],c[2]!==p||c[3]!==m?(i=(0,t.jsxs)("span",{children:[m,": ",p]}),c[2]=p,c[3]=m,c[4]=i):i=c[4],c[5]!==p||c[6]!==m?(s=(0,t.jsx)(n.CopyIcon,{size:14,className:"cursor-pointer hover:text-red-300",onClick:()=>{navigator.clipboard.writeText(p).then(()=>{L.toast.success(`Copied ${m.toLowerCase()} to clipboard`)}).catch(()=>{L.toast.error(`Failed to copy ${m.toLowerCase()} to clipboard`)})}}),c[5]=p,c[6]=m,c[7]=s):s=c[7],c[8]!==o||c[9]!==i||c[10]!==s?(l=(0,t.jsxs)("div",{className:o,children:[i,s]}),c[8]=o,c[9]=i,c[10]=s,c[11]=l):l=c[11],l):null},"DebugMenu",0,function(){let e,n,o,i,c,g=(0,a.c)(16),{t:v}=(0,D.useTranslation)("base"),b=j(),[x,y]=(0,m.useLocalStorage)(T,!1);g[0]!==x||g[1]!==y?(e=e=>{e.preventDefault(),y(!x)},g[0]=x,g[1]=y,g[2]=e):e=g[2],g[3]!==x?(n=[x],g[3]=x,g[4]=n):n=g[4],g[5]!==b?(o={enabled:b},g[5]=b,g[6]=o):o=g[6],(0,p.useHotkeys)(h.KBD_TOGGLE_DEBUG_MENU,e,n,o);let w=V(),{isSharePage:S,pageData:A}=(0,f.useGrokRouter)(),C=U(),R=function(){let e=V(),{isSharePage:t,pageData:a}=(0,f.useGrokRouter)(),n=(0,r.useChatPageStore)(H),o=(0,r.useChatPageStore)(G);return!!(e&&(n||o)||t&&a?.shareLinkId)}();return C?(g[7]!==R||g[8]!==w||g[9]!==S||g[10]!==A||g[11]!==y||g[12]!==v?(i=R&&(0,t.jsx)("div",{className:(0,k.cn)("fixed top-0 left-1/2 -translate-x-1/2","z-[9999] group pb-4"),children:(0,t.jsxs)("div",{className:(0,k.cn)("-translate-y-[calc(100%-5px)]","group-hover:translate-y-0","transition-transform duration-200","ease-out delay-1000","group-hover:delay-0","flex items-center gap-1.5 px-3 py-1","bg-surface-l1/80 backdrop-blur-sm","border border-t-0 border-border-l1","rounded-b-lg shadow-sm","text-xs leading-none","text-secondary font-normal","[&_svg]:translate-y-px"),children:[w&&(0,t.jsx)(W,{}),w&&(0,t.jsx)($,{}),w&&(0,t.jsx)(ee,{}),w&&(0,t.jsx)(ea,{}),w&&(0,t.jsx)(eo,{}),S&&A?.shareLinkId&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(W,{shareLinkId:A.shareLinkId}),(0,t.jsx)(K,{shareLinkId:A.shareLinkId})]}),(0,t.jsxs)(d.Popover,{children:[(0,t.jsx)(d.PopoverTrigger,{hoverOpen:!0,asChild:!0,children:(0,t.jsx)(u.IconButton,{variant:"none",size:"none",shape:"circle",className:(0,k.cn)("text-secondary hover:text-fg-primary","p-0.5 focus-visible:ring-0"),tabIndex:-1,"aria-label":"Debug info",children:(0,t.jsx)(s.Info,{size:11})})}),(0,t.jsx)(d.PopoverContent,{hoverOpen:!0,sideOffset:4,className:"p-3 max-w-64",children:(0,t.jsx)("p",{className:"text-[11px] text-secondary italic",children:"This is the debug menu. It is only visible to internal users and is not part of the website. Toggle with ⌘⇧."})})]}),(0,t.jsx)(u.IconButton,{variant:"none",size:"none",shape:"circle",onClick:()=>{y(!0)},"aria-label":v("debug-menu-close.label","Close"),className:(0,k.cn)("text-secondary hover:text-fg-primary","p-0.5 focus-visible:ring-0"),children:(0,t.jsx)(l.X,{size:11})})]})}),g[7]=R,g[8]=w,g[9]=S,g[10]=A,g[11]=y,g[12]=v,g[13]=i):i=g[13],g[14]!==i?(c=(0,t.jsx)(t.Fragment,{children:i}),g[14]=i,g[15]=c):c=g[15],c):null},"DebugResponse",0,function(e){let r,n,o,s,l,c,h,f,p,m,g,v,b,x,y=(0,a.c)(30),{response:w,className:S}=e,A=U();w.metadata?.requestModelDetails?.name,w.metadata?.requestModelDetails?.description,w.metadata?.requestModelDetails?.modelId,w.metadata?.request_trace_id;let C=w.metadata?.requestModelDetails?.modelId,R=w.metadata?.requestModelDetails?.name,P=w.metadata?.requestModelDetails?.description,_=w.metadata?.request_trace_id,I=R??C;y[0]!==w.responseId?(r={label:"res id",value:w.responseId},y[0]=w.responseId,y[1]=r):r=y[1],y[2]!==I?(n={label:"model",value:I},y[2]=I,y[3]=n):n=y[3],y[4]!==P?(o={label:"model description",value:P},y[4]=P,y[5]=o):o=y[5],y[6]!==_?(s=_?{type:"axiom-trace",params:{traceId:_}}:void 0,y[6]=_,y[7]=s):s=y[7],y[8]!==_||y[9]!==s?(l={label:"req trace id",value:_,debugLink:s},y[8]=_,y[9]=s,y[10]=l):l=y[10],y[11]!==r||y[12]!==n||y[13]!==o||y[14]!==l?(c=[r,n,o,l].filter(el),y[11]=r,y[12]=n,y[13]=o,y[14]=l,y[15]=c):c=y[15];let D=c;return A?(y[16]!==S?(h=(0,k.cn)("print:hidden focus-visible:ring-0",S),y[16]=S,y[17]=h):h=y[17],y[18]===Symbol.for("react.memo_cache_sentinel")?(f=(0,t.jsx)(i.Bug,{size:14}),y[18]=f):f=y[18],y[19]!==h?(p=(0,t.jsx)(d.PopoverTrigger,{asChild:!0,hoverOpen:!0,children:(0,t.jsx)(u.IconButton,{variant:"tertiary",size:"md",shape:"circle",tabIndex:-1,"aria-label":"Debug information",className:h,children:f})}),y[19]=h,y[20]=p):p=y[20],y[21]===Symbol.for("react.memo_cache_sentinel")?(m=(0,k.cn)("font-normal text-xs","flex flex-col gap-0.5 p-3"),y[21]=m):m=y[21],y[22]!==D?(g=D.map(es),y[22]=D,y[23]=g):g=y[23],y[24]===Symbol.for("react.memo_cache_sentinel")?(v=(0,t.jsx)("p",{className:"text-secondary italic text-[11px] mt-2",children:"Debug info — only visible to internal employees"}),y[24]=v):v=y[24],y[25]!==g?(b=(0,t.jsx)(d.PopoverContent,{hoverOpen:!0,sideOffset:4,children:(0,t.jsxs)("div",{className:m,children:[g,v]})}),y[25]=g,y[26]=b):b=y[26],y[27]!==b||y[28]!==p?(x=(0,t.jsxs)(d.Popover,{children:[p,b]}),y[27]=b,y[28]=p,y[29]=x):x=y[29],x):null},"canSeeDebugMenu",0,M,"getExportResponseChatJSONString",0,ed,"isConversationDebugSurface",0,O,"openDebugLink",0,z,"useCanSeeDebugMenu",0,j,"useDebugMenuVisible",0,U],4255400)},4043470,e=>{"use strict";var t=e.i(8633562);e.s(["useMergeRefs",0,function(...e){return(0,t.useCallback)(t=>{for(let a of e)"function"==typeof a?a(t):a&&(a.current=t)},e)}])},1055378,e=>{"use strict";var t=e.i(6585069),a=e.i(9795581);let r=(0,a.default)("Atom",[["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}],["path",{d:"M20.2 20.2c2.04-2.03.02-7.36-4.5-11.9-4.54-4.52-9.87-6.54-11.9-4.5-2.04 2.03-.02 7.36 4.5 11.9 4.54 4.52 9.87 6.54 11.9 4.5Z",key:"1l2ple"}],["path",{d:"M15.7 15.7c4.52-4.54 6.54-9.87 4.5-11.9-2.03-2.04-7.36-.02-11.9 4.5-4.52 4.54-6.54 9.87-4.5 11.9 2.03 2.04 7.36.02 11.9-4.5Z",key:"1wam0m"}]]);var n=e.i(7686264),n=n,o=e.i(7868894),i=e.i(9200194),s=e.i(7745209),s=s;let l=(0,a.default)("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]]);var c=e.i(6801495),u=e.i(5654828),d=e.i(1016144),h=e.i(843446),f=e.i(8634206),p=e.i(4508272),m=e.i(8459756),g=e.i(7704207);let v={assistant:r,translator:i.LanguagesIcon,therapist:t.ArmchairIcon,storyteller:n.default,"kids-stories":d.default,"kids-trivia":l,meditation:f.default,conspiracy:m.default,doctor:s.default,unhinged:p.default,sexy:o.FlameIcon,motivation:h.default,romantic:u.default,argumentative:c.ZapIcon};e.s(["personalityIconMap",0,v,"useVoiceSettings",0,function(){return(0,g.useFeatureFlags)().VOICE_MODE_CONFIG}],1055378)},2208,e=>{"use strict";var t=e.i(6877861);e.s(["allowMatureContent",0,function(e){return"verified"===e},"resolveCurrentVoice",0,function(e,a){let r=(0,t.canonicalizeVoiceWireId)(e),n=a.find(e=>e.id===r);if(n)return n;let o=(0,t.parseBuiltInVoice)(r);return o?(0,t.voiceToConfig)(o):void 0},"resolveVoicePick",0,function(e){let a=(0,t.canonicalizeVoiceWireId)(e.selectedId),r=e.voices.find(e=>e.id===a);return(r?.mature??(0,t.parseBuiltInVoice)(a)?.mature)&&!e.allowMature?{action:"age-gate"}:{action:"select",voiceId:a}}])},7131196,e=>{"use strict";var t=e.i(8633562),a=e.i(9219141),r=e.i(6922257),n=e.i(3193047),o=e.i(7024528),i=e.i(6807109),s=e.i(6070088),l=e.i(2983297),c=e.i(9227737),u=e.i(6484739),d=e.i(4892686),h=e.i(25464),f=["PageUp","PageDown"],p=["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"],m={"from-left":["Home","PageDown","ArrowDown","ArrowLeft"],"from-right":["Home","PageDown","ArrowDown","ArrowRight"],"from-bottom":["Home","PageDown","ArrowDown","ArrowLeft"],"from-top":["Home","PageDown","ArrowUp","ArrowLeft"]},g="Slider",[v,b,x]=(0,d.createCollection)(g),[y,w]=(0,o.createContextScope)(g,[x]),[S,A]=y(g),k=t.forwardRef((e,n)=>{let{name:o,min:s=0,max:l=100,step:c=1,orientation:u="horizontal",disabled:d=!1,minStepsBetweenThumbs:m=0,defaultValue:g=[s],value:b,onValueChange:x=()=>{},onValueCommit:y=()=>{},inverted:w=!1,form:A,...k}=e,C=t.useRef(new Set),R=t.useRef(0),I="horizontal"===u,[D=[],L]=(0,i.useControllableState)({prop:b,defaultProp:g,onChange:e=>{let t=[...C.current];t[R.current]?.focus(),x(e)}}),E=t.useRef(D);function T(e,t,{commit:r}={commit:!1}){let n,o=(String(c).split(".")[1]||"").length,i=Math.round((Math.round((e-s)/c)*c+s)*(n=Math.pow(10,o)))/n,u=(0,a.clamp)(i,[s,l]);L((e=[])=>{let a=function(e=[],t,a){let r=[...e];return r[a]=t,r.sort((e,t)=>e-t)}(e,u,t);if(!function(e,t){if(t>0)return Math.min(...e.slice(0,-1).map((t,a)=>e[a+1]-t))>=t;return!0}(a,m*c))return e;{R.current=a.indexOf(u);let t=String(a)!==String(e);return t&&r&&y(a),t?a:e}})}return(0,h.jsx)(S,{scope:e.__scopeSlider,name:o,disabled:d,min:s,max:l,valueIndexToChangeRef:R,thumbs:C.current,values:D,orientation:u,form:A,children:(0,h.jsx)(v.Provider,{scope:e.__scopeSlider,children:(0,h.jsx)(v.Slot,{scope:e.__scopeSlider,children:(0,h.jsx)(I?P:_,{"aria-disabled":d,"data-disabled":d?"":void 0,...k,ref:n,onPointerDown:(0,r.composeEventHandlers)(k.onPointerDown,()=>{d||(E.current=D)}),min:s,max:l,inverted:w,onSlideStart:d?void 0:function(e){let t=function(e,t){if(1===e.length)return 0;let a=e.map(e=>Math.abs(e-t)),r=Math.min(...a);return a.indexOf(r)}(D,e);T(e,t)},onSlideMove:d?void 0:function(e){T(e,R.current)},onSlideEnd:d?void 0:function(){let e=E.current[R.current];D[R.current]!==e&&y(D)},onHomeKeyDown:()=>!d&&T(s,0,{commit:!0}),onEndKeyDown:()=>!d&&T(l,D.length-1,{commit:!0}),onStepKeyDown:({event:e,direction:t})=>{if(!d){let a=f.includes(e.key)||e.shiftKey&&p.includes(e.key),r=R.current;T(D[r]+c*(a?10:1)*t,r,{commit:!0})}}})})})})});k.displayName=g;var[C,R]=y(g,{startEdge:"left",endEdge:"right",size:"width",direction:1}),P=t.forwardRef((e,a)=>{let{min:r,max:o,dir:i,inverted:l,onSlideStart:c,onSlideMove:u,onSlideEnd:d,onStepKeyDown:f,...p}=e,[g,v]=t.useState(null),b=(0,n.useComposedRefs)(a,e=>v(e)),x=t.useRef(void 0),y=(0,s.useDirection)(i),w="ltr"===y,S=w&&!l||!w&&l;function A(e){let t=x.current||g.getBoundingClientRect(),a=z([0,t.width],S?[r,o]:[o,r]);return x.current=t,a(e-t.left)}return(0,h.jsx)(C,{scope:e.__scopeSlider,startEdge:S?"left":"right",endEdge:S?"right":"left",direction:S?1:-1,size:"width",children:(0,h.jsx)(I,{dir:y,"data-orientation":"horizontal",...p,ref:b,style:{...p.style,"--radix-slider-thumb-transform":"translateX(-50%)"},onSlideStart:e=>{let t=A(e.clientX);c?.(t)},onSlideMove:e=>{let t=A(e.clientX);u?.(t)},onSlideEnd:()=>{x.current=void 0,d?.()},onStepKeyDown:e=>{let t=m[S?"from-left":"from-right"].includes(e.key);f?.({event:e,direction:t?-1:1})}})})}),_=t.forwardRef((e,a)=>{let{min:r,max:o,inverted:i,onSlideStart:s,onSlideMove:l,onSlideEnd:c,onStepKeyDown:u,...d}=e,f=t.useRef(null),p=(0,n.useComposedRefs)(a,f),g=t.useRef(void 0),v=!i;function b(e){let t=g.current||f.current.getBoundingClientRect(),a=z([0,t.height],v?[o,r]:[r,o]);return g.current=t,a(e-t.top)}return(0,h.jsx)(C,{scope:e.__scopeSlider,startEdge:v?"bottom":"top",endEdge:v?"top":"bottom",size:"height",direction:v?1:-1,children:(0,h.jsx)(I,{"data-orientation":"vertical",...d,ref:p,style:{...d.style,"--radix-slider-thumb-transform":"translateY(50%)"},onSlideStart:e=>{let t=b(e.clientY);s?.(t)},onSlideMove:e=>{let t=b(e.clientY);l?.(t)},onSlideEnd:()=>{g.current=void 0,c?.()},onStepKeyDown:e=>{let t=m[v?"from-bottom":"from-top"].includes(e.key);u?.({event:e,direction:t?-1:1})}})})}),I=t.forwardRef((e,t)=>{let{__scopeSlider:a,onSlideStart:n,onSlideMove:o,onSlideEnd:i,onHomeKeyDown:s,onEndKeyDown:l,onStepKeyDown:c,...d}=e,m=A(g,a);return(0,h.jsx)(u.Primitive.span,{...d,ref:t,onKeyDown:(0,r.composeEventHandlers)(e.onKeyDown,e=>{"Home"===e.key?(s(e),e.preventDefault()):"End"===e.key?(l(e),e.preventDefault()):f.concat(p).includes(e.key)&&(c(e),e.preventDefault())}),onPointerDown:(0,r.composeEventHandlers)(e.onPointerDown,e=>{let t=e.target;t.setPointerCapture(e.pointerId),e.preventDefault(),m.thumbs.has(t)?t.focus():n(e)}),onPointerMove:(0,r.composeEventHandlers)(e.onPointerMove,e=>{e.target.hasPointerCapture(e.pointerId)&&o(e)}),onPointerUp:(0,r.composeEventHandlers)(e.onPointerUp,e=>{let t=e.target;t.hasPointerCapture(e.pointerId)&&(t.releasePointerCapture(e.pointerId),i(e))})})}),D="SliderTrack",L=t.forwardRef((e,t)=>{let{__scopeSlider:a,...r}=e,n=A(D,a);return(0,h.jsx)(u.Primitive.span,{"data-disabled":n.disabled?"":void 0,"data-orientation":n.orientation,...r,ref:t})});L.displayName=D;var E="SliderRange",T=t.forwardRef((e,a)=>{let{__scopeSlider:r,...o}=e,i=A(E,r),s=R(E,r),l=t.useRef(null),c=(0,n.useComposedRefs)(a,l),d=i.values.length,f=i.values.map(e=>B(e,i.min,i.max)),p=d>1?Math.min(...f):0,m=100-Math.max(...f);return(0,h.jsx)(u.Primitive.span,{"data-orientation":i.orientation,"data-disabled":i.disabled?"":void 0,...o,ref:c,style:{...e.style,[s.startEdge]:p+"%",[s.endEdge]:m+"%"}})});T.displayName=E;var M="SliderThumb",N=t.forwardRef((e,a)=>{let r=b(e.__scopeSlider),[o,i]=t.useState(null),s=(0,n.useComposedRefs)(a,e=>i(e)),l=t.useMemo(()=>o?r().findIndex(e=>e.ref.current===o):-1,[r,o]);return(0,h.jsx)(j,{...e,ref:s,index:l})}),j=t.forwardRef((e,a)=>{var o,i,s,l,d;let f,p,{__scopeSlider:m,index:g,name:b,...x}=e,y=A(M,m),w=R(M,m),[S,k]=t.useState(null),C=(0,n.useComposedRefs)(a,e=>k(e)),P=!S||y.form||!!S.closest("form"),_=(0,c.useSize)(S),I=y.values[g],D=void 0===I?0:B(I,y.min,y.max),L=(o=g,(i=y.values.length)>2?`Value ${o+1} of ${i}`:2===i?["Minimum","Maximum"][o]:void 0),E=_?.[w.size],T=E?(s=E,l=D,d=w.direction,p=z([0,50],[0,f=s/2]),(f-p(l)*d)*d):0;return t.useEffect(()=>{if(S)return y.thumbs.add(S),()=>{y.thumbs.delete(S)}},[S,y.thumbs]),(0,h.jsxs)("span",{style:{transform:"var(--radix-slider-thumb-transform)",position:"absolute",[w.startEdge]:`calc(${D}% + ${T}px)`},children:[(0,h.jsx)(v.ItemSlot,{scope:e.__scopeSlider,children:(0,h.jsx)(u.Primitive.span,{role:"slider","aria-label":e["aria-label"]||L,"aria-valuemin":y.min,"aria-valuenow":I,"aria-valuemax":y.max,"aria-orientation":y.orientation,"data-orientation":y.orientation,"data-disabled":y.disabled?"":void 0,tabIndex:y.disabled?void 0:0,...x,ref:C,style:void 0===I?{display:"none"}:e.style,onFocus:(0,r.composeEventHandlers)(e.onFocus,()=>{y.valueIndexToChangeRef.current=g})})}),P&&(0,h.jsx)(F,{name:b??(y.name?y.name+(y.values.length>1?"[]":""):void 0),form:y.form,value:I},g)]})});N.displayName=M;var F=e=>{let{value:a,...r}=e,n=t.useRef(null),o=(0,l.usePrevious)(a);return t.useEffect(()=>{let e=n.current,t=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value").set;if(o!==a&&t){let r=new Event("input",{bubbles:!0});t.call(e,a),e.dispatchEvent(r)}},[o,a]),(0,h.jsx)("input",{style:{display:"none"},...r,ref:n,defaultValue:a})};function B(e,t,r){return(0,a.clamp)(100/(r-t)*(e-t),[0,100])}function z(e,t){return a=>{if(e[0]===e[1]||t[0]===t[1])return t[0];let r=(t[1]-t[0])/(e[1]-e[0]);return t[0]+r*(a-e[0])}}e.s(["Range",0,T,"Root",0,k,"Slider",0,k,"SliderRange",0,T,"SliderThumb",0,N,"SliderTrack",0,L,"Thumb",0,N,"Track",0,L,"createSliderScope",0,w],2977503);var U=e.i(2977503);e.s(["Slider",0,U],7131196)},9330330,e=>{"use strict";var t=e.i(653551);e.s(["VisuallyHidden",0,t])},1979495,e=>{e.q("https://cdn.grok.com/_next/static/media/orb-worker.2o_uprhtyr8-i.ts")},1047113,e=>{e.q("https://cdn.grok.com/_next/static/media/placeholder-orb.3vdgr_lx46lxv.png")},7408042,e=>{"use strict";let t=`
attribute vec2 aPos;
attribute vec2 aUV;
varying vec2 vUV;
void main() {
  vUV = aUV;
  gl_Position = vec4(aPos, 0.0, 1.0);
}`,a=`
float h1(float x) { return fract(sin(x * 127.1) * 43758.5453); }

// ── starfield — a real galaxy in a glass sphere: a tilted galactic band
// of dense star-dust and glowing nebula pockets, dark dust lanes cutting
// through it, three scales of twinkling stars, deep-space black behind.
vec4 starfield(vec3 n, float t) {
  float lon = atan(n.z, n.x);
  float lat = asin(clamp(n.y, -1.0, 1.0));

  // per-orb structural variance, derived from the seed phase: every orb gets
  // its own galaxy — band tilt/undulation/width, star density, pocket hues
  float v1 = fract(uPhase * 7.13);
  float v2 = fract(uPhase * 3.71);
  float v3 = fract(uPhase * 5.37);

  // ── galaxy ARCHETYPE: each orb is one of four different skies
  // 0 spiral (milky-way band) \xb7 1 emission nebula (vivid cloud, few stars)
  // 2 galactic core (warm blazing bulge) \xb7 3 deep field (sparse, crystalline)
  float at = uArch >= 0.0 ? uArch : floor(fract(uPhase * 9.73) * 4.0);
  float isNeb = step(0.5, at) * (1.0 - step(1.5, at));
  float isCore = step(1.5, at) * (1.0 - step(2.5, at));
  float isDeep = step(2.5, at);

  // galactic plane: density concentrates in a band around a tilted equator.
  // lon frequencies MUST be integers: lon wraps at \xb1π, and a non-integer
  // frequency doesn't tile across that seam — it stamps a hard crease that
  // tumbles into view as the sphere spins.
  float gb = lat + (0.15 + 0.4 * v1) * sin(lon * (1.0 + floor(v2 * 2.0)) + 1.3)
           + 0.12 * sin(lon * 3.0 + t * 0.1);
  float band = exp(-gb * gb * (5.0 + 10.0 * v3));
  band = mix(band, max(band, 0.8), isNeb); // nebula: cloud fills the whole sky
  band *= 1.0 - 0.85 * isDeep; // deep field: nearly empty void

  // nebula: two octaves of warped wisps, glowing pockets along the band
  float n1 = sin(lon * 2.0 + sin(lat * 3.0 + t * 0.25) * 1.6 + t * 0.15);
  float n2 = sin(lon * 5.0 - sin(lat * 4.0 - t * 0.2) * 1.2 - t * 0.22 + 2.4);
  float neb = pow(0.5 + 0.5 * n1, 2.0) * (0.45 + 0.55 * pow(0.5 + 0.5 * n2, 2.0));
  // dark dust lanes carved through the bright band
  float lane = pow(0.5 + 0.5 * sin(lon * 4.0 + lat * 7.0 + sin(lon * 2.0) * 2.0), 3.0);
  float galaxy = band * neb * (1.0 - lane * (0.55 + 0.35 * v2));
  float w0g = clamp(galaxy, 0.0, 1.0); // ensure the band registers in alpha
  galaxy = w0g;
  // Milky-Way dust: mostly cool blue-white star haze, the palette only as a
  // faint cast — real galaxies are desaturated except the warm core
  // per-orb color identity: how strongly (and with which accents) the dust is
  // tinted varies orb to orb — some stay silver-blue, others go violet/amber
  vec3 hue = mix(mix(uC0, uC1, v1), mix(uC1, uC2, v3), 0.5 + 0.5 * sin(lon + lat * 2.0 - t * 0.2));
  // saturation push: keep the dust hue vivid even after all the mixing
  vec3 hueGrey = vec3(dot(hue, vec3(0.299, 0.587, 0.114)));
  hue = clamp(hueGrey + (hue - hueGrey) * 1.45, 0.0, 1.0);
  // the palette carries each agent's identity — dust leans firmly into it
  // (different agents on one screen read as different colored skies)
  vec3 dust = mix(vec3(0.72, 0.78, 0.92), hue, 0.45 + 0.3 * v1 + 0.45 * isNeb);
  vec3 col = dust * galaxy * (0.6 + 0.9 * isNeb);
  // rotation streaks: faint orbital shear lines inside the band, drifting —
  // the galaxy visibly *turns*
  float shear = sin(lon * 13.0 + lat * 4.0 - t * 0.35) * sin(lon * 5.0 + t * 0.2);
  col += dust * band * neb * max(shear, 0.0) * 0.14;
  // a second, fainter dust arm crossing the main band — spiral-galaxy depth
  float gb2 = lat - (0.35 + 0.25 * v2) * sin(lon * 2.0 - 1.1) + 0.4;
  float arm = exp(-gb2 * gb2 * 7.0) * neb;
  col += mix(dust, uC1, 0.35) * arm * 0.2;
  // the void itself is never pure black: a whisper of deep indigo that
  // breathes — the "magic" ambient of a long-exposure sky
  // the void itself carries the agent's hue — the strongest identity cue,
  // since it covers the whole sphere
  vec3 voidGlow = mix(vec3(0.04, 0.03, 0.1), mix(uC0, mix(uC1, uC2, v3), v1) * 0.22, 0.75);
  col += voidGlow * (0.5 + 0.22 * sin(t * 0.4 + lon)) * (0.4 + 0.6 * band);
  // warm amber core glow deep in the band
  col += vec3(1.0, 0.88, 0.68) * pow(band, 4.0) * pow(neb, 2.0) * 0.4;
  // galactic-core archetype: a blazing warm bulge with a halo of star-fog,
  // fixed to the rotating sphere so it wheels around as the galaxy turns
  float ca = v2 * 6.28318;
  vec3 Cdir = normalize(vec3(cos(ca) * 0.85, 0.6 * (v3 - 0.5), sin(ca) * 0.85));
  float bulge = max(dot(n, Cdir), 0.0);
  col += mix(vec3(1.0, 0.85, 0.6), uC2, 0.25) * (pow(bulge, 14.0) * 1.6 + pow(bulge, 4.0) * 0.5) * isCore;
  // nebula pockets, two layers in different hues: hot spots of saturated
  // palette color glowing in the dust, slowly breathing
  float pocket = pow(neb, 5.0) * band * (0.7 + 0.3 * sin(t * 0.6 + lon * 3.0));
  col += mix(uC2, uC0, fract(v1 + 0.5 * sin(lon * 2.0) + 0.5)) * pocket * (0.5 + 0.4 * v2 + 0.8 * isNeb);
  float pocket2 = pow(0.5 + 0.5 * sin(lon * 3.0 + lat * 4.0 - t * 0.18 + 2.0), 6.0) * band;
  col += mix(uC1, uC2, v3) * pocket2 * (0.25 + 0.3 * v1 + 0.5 * isNeb);
  // Detail factor by orb size (1 = large): small list orbs keep faded bright stars but drop the grain
  // and most of the dense faint dust — those are what read as granular noise / alias at list sizes.
  float detail = smoothstep(90.0, 200.0, uRes.y);
  // milky grain: ultra-fine star dust packed into the band — the granular
  // texture that says "Milky Way" in long-exposure shots
  vec2 gg = vec2(lon, lat) * 34.0;
  vec2 gc = floor(gg);
  vec2 gf = fract(gg);
  float gh = h1(gc.x * 3.7 + gc.y * 11.3);
  vec2 gp = vec2(0.2 + 0.6 * h1(gh * 91.0), 0.2 + 0.6 * h1(gh * 47.0));
  float gd = length((gf - gp) * vec2(cos(lat), 1.0));
  float grain = exp(-gd * gd * 700.0 * clamp(uRes.y / 420.0, 0.22, 1.0)) * step(0.3, gh) * (0.15 + 0.85 * band);
  col += vec3(0.88, 0.9, 1.0) * grain * 0.4 * detail;
  float w = clamp(galaxy * 0.7 + pow(band, 4.0) * 0.25, 0.0, 1.0);



  // three star scales: a few bright, many mid, dense faint dust (denser in band)
  for (int s = 0; s < 3; s++) {
    float K = s == 0 ? 6.0 : (s == 1 ? 11.0 : 19.0);
    vec2 g = vec2(lon, lat) * K;
    vec2 cell = floor(g);
    vec2 f = fract(g);
    float hx = h1(cell.x * 13.7 + cell.y * 7.3 + float(s) * 91.0);
    float hy = h1(cell.x * 5.1 + cell.y * 17.9 + float(s) * 37.0);
    vec2 sp = vec2(0.15 + 0.7 * hx, 0.15 + 0.7 * hy);
    float d = length((f - sp) * vec2(cos(lat), 1.0));
    // archetype star census: nebulae are star-poor, cores star-rich,
    // deep fields sparse but every star counts
    float census = (v2 - 0.5) * 0.2 + 0.35 * isNeb - 0.2 * isCore + 0.3 * isDeep;
    float keep = step((s == 2 ? 0.3 : 0.55) + census, h1(hx * 89.0 + hy * 31.0) + band * 0.25);
    // small orbs: stars must stay >= ~1px and twinkle gently, or they alias
    // into flicker as the sphere tumbles
    float resFac = clamp(uRes.y / 420.0, 0.22, 1.0);
    float tw = mix(0.92, 0.6 + 0.4 * sin(t * (1.5 + 3.0 * hx) + hx * 40.0), resFac);
    // per-star size: each star draws its own radius from the hash (4x range),
    // and brightness follows size — a real magnitude distribution
    float hz = h1(hx * 53.0 + hy * 71.0 + cell.x);
    float sizeJit = 0.35 + 1.8 * hz * hz; // few big, many small
    float sharp = (s == 0 ? 260.0 : (s == 1 ? 700.0 : 1600.0)) / sizeJit * resFac;
    float star = exp(-d * d * sharp) * keep * tw;
    // near-white stars with the faintest temperature variation, like the sky
    vec3 tint = mix(vec3(1.0), hx < 0.33 ? vec3(0.85, 0.9, 1.0) : (hx < 0.66 ? vec3(1.0, 0.95, 0.85) : mix(vec3(1.0), uC1, 0.3)), 0.6);
    float bright = (s == 0 ? 1.7 : (s == 1 ? 0.9 : 0.5)) * (0.55 + 0.7 * sizeJit);
    // small orbs: keep the bright/mid stars (just faded), but drop most of the dense faint dust (s==2)
    // and the grain — those are what read as granular noise at list sizes.
    float starFade = mix(s == 2 ? 0.14 : 0.45, 1.0, detail);
    col += tint * star * bright * starFade;
    // the biggest stars get a soft halo bloom + diffraction-cross sparkle
    if (s == 0) {
      float big = smoothstep(1.2, 2.0, sizeJit);
      col += tint * exp(-d * d * 60.0) * 0.18 * big * tw * starFade;
      vec2 dd = (f - sp) * vec2(cos(lat), 1.0);
      float spike = exp(-dd.x * dd.x * 1200.0) * exp(-dd.y * dd.y * 26.0)
                  + exp(-dd.y * dd.y * 1200.0) * exp(-dd.x * dd.x * 26.0);
      col += tint * spike * 0.3 * big * tw * starFade;
      w = max(w, spike * 0.3 * big * starFade);
    }
    w = max(w, star * min(bright, 1.5) * starFade);
  }

  // pulsar: one bright star per orb that flashes rhythmically with a halo —
  // audio pushes its beat brighter and faster
  float pa = v1 * 6.28318;
  vec3 P = normalize(vec3(sin(pa) * 0.9, 1.4 * (v2 - 0.5), cos(pa) * 0.9));
  float pd = max(dot(n, P), 0.0);
  float beat = pow(0.5 + 0.5 * sin(t * (1.2 + v3 + 1.5 * uAudio) + v3 * 6.28), 8.0);
  beat = min(1.0, beat + 0.6 * uAudio);
  float pulsarFade = mix(0.45, 1.0, detail);
  col += vec3(0.9, 0.95, 1.0) * (pow(pd, 900.0) * (0.6 + 1.2 * beat) + pow(pd, 110.0) * 0.5 * beat) * pulsarFade;
  w = max(w, pow(pd, 900.0) * (0.5 + 0.5 * beat) * pulsarFade);

  return vec4(min(col, vec3(1.0)), min(w, 1.0));
}

// Sample the rotating sphere at 3D point n (unit sphere). The ball TUMBLES:
// it spins around a tilted axis while that axis itself slowly precesses and
// the whole ball rolls — rotation on multiple axes, like a marble turned in
// the hand, so the pattern travels over the poles too, not just sideways.
vec4 sphereAt(vec3 n, float spin, float t) {
  float roll = t * 0.13; // roll around the view axis
  float cr = cos(roll), sr = sin(roll);
  n = vec3(cr * n.x - sr * n.y, sr * n.x + cr * n.y, n.z);
  float tilt = 0.45 + 0.35 * sin(t * 0.24); // precessing axis
  float cx = cos(tilt), sx = sin(tilt);
  n = vec3(n.x, cx * n.y - sx * n.z, sx * n.y + cx * n.z);
  float cs = cos(spin), ss = sin(spin);
  n = vec3(cs * n.x + ss * n.z, n.y, -ss * n.x + cs * n.z);
  return starfield(n, t);
}

// The whole orb as a pure function of the (pre-lens) screen point p — the
// in-shader lens re-evaluates this at displaced coordinates per RGB channel.
vec3 shade(vec2 p) {
  float r = length(p);
  // No alpha mask: the shader renders edge-to-edge of the square canvas
  // (the limb colors smear outward past r=1 as overscan), so the lens —
  // SVG or in-shader — always has pixels to displace; otherwise it pulls
  // transparent samples and stamps a hard arc inside the sphere. The CSS
  // clip-path on the canvas wrapper cuts the true circular silhouette.
#ifndef DUAL_LAYER
  // Batch (list) orbs have no lens, so the square corners are never used —
  // discard them to skip the whole galaxy compute for ~21% of pixels.
  if (r > 1.0) { discard; }
#endif
  float t = uTime * 0.8 + uPhase;

  // sphere geometry
  float rr = min(r, 0.9995);
  float z = sqrt(1.0 - rr * rr);
  vec3 N = vec3(p.x, p.y, z);
  float fres = pow(1.0 - z, 2.4); // 0 center -> 1 at the limb

  // Front hemisphere point is N itself; the see-through far wall is hit by
  // the refracted ray continuing through the glass to the back of the ball.
  vec3 I = vec3(0.0, 0.0, -1.0);
  vec3 R = refract(I, N, 0.75);
  // exit point of the ray on the back of the unit sphere
  float dHit = -2.0 * dot(N, R);
  vec3 B = normalize(N + R * dHit);

  // both layers live on the SAME rotating sphere — the front face and the
  // far wall seen through the glass — so the whole ball reads as one object
  // spinning, with the back side counter-sliding in true perspective.
  // organic motion: the spin angle is integrated on the CPU (uSpin) so the
  // rotation can accelerate, ease, and reverse smoothly — especially under
  // audio. Pattern time keeps its own gentle warp for non-linear drift.
  float sv = fract(uPhase * 6.31);
  float sw = fract(uPhase * 2.17);
  float tWarp = t
    + (0.9 + 1.3 * sv) * sin(t * (0.09 + 0.07 * sw))
    + (0.5 + 0.8 * sw) * sin(t * (0.21 + 0.09 * sv) + 2.6);
  vec4 front = sphereAt(N, uSpin, tWarp);
  // The back-wall galaxy sample doubles fragment cost; only the hero (single-orb)
  // program keeps it. Batched list orbs skip it (invisible at small sizes).
#ifdef DUAL_LAYER
  vec4 back = sphereAt(B, uSpin, tWarp * 0.8 + 2.7);
#else
  vec4 back = vec4(0.0);
#endif

  // glass body: deep-space glass — near-black void with the anchor color
  // breathing at the rim; just enough page light leaks through the edge
  // to keep it reading as glass rather than a flat black disc
  vec3 voidCol = mix(uAnchor * 0.04, uAnchor * 0.35, fres);
  vec3 col = mix(uBg, voidCol, 0.97 - 0.04 * fres);
  // mix (not add): the band REPLACES the glass color where it lives, so it
  // reads on light pages instead of clipping to white
  float fa = clamp(front.a, 0.0, 1.0);
  float ba = clamp(back.a, 0.0, 1.0);
  col = mix(col, back.rgb, ba * 0.16); // far-wall echo
  col = mix(col, front.rgb, fa * 0.85);
  {
    // ── aurora borealis, voice as light — drawn in VIEW space so the
    // curtains always hang in the visible upper sky (the galaxy tumbles
    // behind them). Amplitude undulates like speech; fine rays shimmer
    // through; classic green at the base climbing into violet.
    float alon = atan(N.x, N.z);
    float speech = pow(0.5 + 0.5 * sin(alon * 3.0 + sin(alon * 7.0 + t * 1.1) * 0.7 + t * 0.5), 3.0)
                 * (0.55 + 0.45 * sin(alon * 5.0 - t * 0.65 + 1.7));
    float sky = -N.y; // canvas blit flips Y: -N.y is the visible upper sky
    float hang = smoothstep(-0.15, 0.5, sky);
    float rays = 0.7 + 0.3 * sin(alon * 24.0 + sin(alon * 9.0 - t * 0.8) * 2.0 + t * 1.6);
    // audio: the voice IS the aurora — curtains surge with live amplitude
    float aur = clamp(speech, 0.0, 1.0) * hang * rays * (1.0 + 2.2 * uAudio);
    // per-orb aurora character: some classic green→violet, others lean into
    // the palette (teal→pink, blue→gold…)
    float av = fract(uPhase * 2.93);
    vec3 aurCol = mix(vec3(0.12, 0.95, 0.55), vec3(0.45, 0.35, 1.0),
                      smoothstep(0.0, 0.95, sky + 0.35 * speech));
    aurCol = mix(aurCol, mix(uC0, uC2, av), 0.15 + 0.4 * av);
    col += aurCol * aur * 0.8;

    // shooting star: every ~6s a meteor streaks across a random trajectory,
    // white-hot head with an exponentially fading tail
    float met = 4.5 + 3.5 * fract(uPhase * 4.91); // per-orb meteor cadence
    float epoch = floor(t / met);
    float ph = fract(t / met);
    vec2 s0 = vec2(-1.1 + 2.2 * h1(epoch * 1.3), 0.85 - 1.4 * h1(epoch * 2.9));
    vec2 sd = normalize(vec2(0.7 + 0.5 * h1(epoch * 4.1), -0.35 - 0.4 * h1(epoch * 5.3)));
    vec2 head = s0 + sd * ph * 2.8;
    vec2 rel = p - head;
    float along = dot(rel, sd);
    float perp = dot(rel, vec2(-sd.y, sd.x));
    float vis = smoothstep(0.0, 0.06, ph) * smoothstep(0.5, 0.32, ph);
    float tail = exp(-perp * perp * 1600.0) * exp(along * 9.0) * step(along, 0.0)
               * smoothstep(-0.5, -0.02, along);
    float headGlow = exp(-dot(rel, rel) * 900.0);
    col += (vec3(1.0) * headGlow * 1.2 + mix(vec3(1.0), uC1, 0.3) * tail * 0.85) * vis;

    // moving illumination: a broad diffuse gradient (a soft terminator)
    // sweeps around the sphere, brightening whole regions of sky and dust in
    // turn — this is what makes the ball feel LIT, not printed
    vec3 LD = normalize(vec3(0.85 * sin(t * 0.42), 0.45 * sin(t * 0.26 + 1.2), 0.5));
    float diffuse = 0.62 + 0.65 * max(dot(N, LD), 0.0);
    // audio: the whole sky brightens and breathes with the voice
    diffuse *= 1.0 + 0.35 * uAudio;
    col *= diffuse;
    // ── voice light: while speaking, a warm core flare wakes deep in the
    // sphere and the rim catches the agent's color — the orb visibly *emits*
    vec3 voiceCol = mix(uC1, vec3(1.0, 0.97, 0.9), 0.45);
    col += voiceCol * pow(1.0 - rr, 1.8) * uAudio * 0.5; // inner flare
    col += (uC1 * 0.7 + vec3(0.12)) * fres * uAudio * 0.65; // rim ignition
    // sparkle excitement: stars glitter harder while the voice is live
    col += col * uAudio * 0.18 * sin(t * 14.0 + rr * 40.0 + uPhase * 7.0);
    // counter-rim: a faint atmospheric glow opposite the moving light
    float counter = max(dot(N.xy, -LD.xy), 0.0) * fres;
    col += mix(uC0, vec3(0.5, 0.6, 0.9), 0.5) * counter * 0.18;
  }

  // 3D lighting off the sphere normal — the key light DRIFTS slowly (like a
  // light source moving in the room) and breathes in intensity, so the glass
  // never feels statically lit
  vec3 L1 = normalize(vec3(-0.45 + 0.3 * sin(t * 0.34), 0.62 + 0.2 * sin(t * 0.27 + 1.7), 0.64));
  float keyAmp = 0.5 * (0.78 + 0.22 * sin(t * 0.45 + 2.2));
  col += vec3(1.0) * pow(max(dot(N, L1), 0.0), 150.0) * keyAmp;
  // broad soft sheen sweeping across the dome on a long period
  vec3 LS = normalize(vec3(sin(t * 0.07) * 0.9, 0.35 + 0.3 * cos(t * 0.05), 0.7));
  col += vec3(1.0) * pow(max(dot(N, LS), 0.0), 7.0) * 0.05;
  vec3 L2 = normalize(vec3(0.52, -0.5 + 0.12 * sin(t * 0.09), 0.69)); // counter glint
  col += vec3(1.0) * pow(max(dot(N, L2), 0.0), 140.0) * 0.25;
  // fresnel rim — a bubble's edge catches a touch of the band's color
  col = mix(col, front.rgb, fa * fres * 0.3);
  // whisper of limb compression
  float limb = smoothstep(0.94, 1.0, rr);
  col = mix(col, col * 0.85, limb * 0.4);

  return col;
}`,r=`
precision highp float;
#define DUAL_LAYER
varying vec2 vUV;
uniform vec2 uRes;
uniform vec3 uBg;
uniform vec3 uAnchor, uC0, uC1, uC2;
uniform float uTime, uPhase;
uniform float uAudio; // live audio level 0..1 — the orb listens
uniform float uSpin; // CPU-integrated spin angle (can accelerate & reverse)
uniform float uArch; // galaxy archetype override; < 0 = derive from seed
uniform float uLens; // in-shader lens displacement (p-units); 0 = lens off
`+a+`
void main() {
  vec2 p = vUV * 2.0 - 1.0;
  if (uLens > 0.0) {
    float r = length(p);
    // erf edge falloff: 0 inside, 1 at the silhouette (erf ≈ tanh(1.7725x),
    // expanded — GLSL ES 1.00 has no tanh); band starts at 1 - depth
    // (depth = 0.1), scale = 1/(depth\xb7√2)
    float ex = exp(2.0 * 1.7724539 * (r - 0.9) / 0.1414214);
    float fall = 0.5 + 0.5 * (ex - 1.0) / (ex + 1.0);
    if (fall > 0.004) {
      // swell: same incommensurate sines the SVG loop animated, so the rim
      // compression re-spikes and the chroma fringe shimmers — free here
      float swell = 1.0 + 0.16 * (0.6 * sin(uTime * 0.9 + uPhase)
                                + 0.4 * sin(uTime * 1.7 + uPhase * 1.3));
      float k = uLens * fall * swell;
      // per-channel displacement (chromaAmount 2 → R \xd71.4, G \xd71.2, B \xd71.0),
      // each with its own slow shimmer (the old per-channel chan factor)
      float cR = 1.4 * (1.0 + 0.06 * sin(uTime * 1.3 + uPhase));
      float cG = 1.2 * (1.0 + 0.06 * sin(uTime * 1.3 + uPhase + 2.1));
      float cB = 1.0 * (1.0 + 0.06 * sin(uTime * 1.3 + uPhase + 4.2));
      vec3 col = vec3(shade(p * (1.0 - k * cR)).r,
                      shade(p * (1.0 - k * cG)).g,
                      shade(p * (1.0 - k * cB)).b);
      // specular pass (the map's B channel): glow lobes at \xb140\xb0 fading in at
      // the rim, plus hard catchlights right at the silhouette edge
      vec2 a2 = min(abs(p), 1.0);
      float lobe = max(abs(a2.x * 0.766 + a2.y * 0.643), abs(a2.x * 0.766 - a2.y * 0.643));
      float glow = 0.65 * pow(clamp((lobe - 0.0707) / 1.3435, 0.0, 1.0), 2.4) * fall;
      glow += 1.02 * clamp(1.0 + (r - 1.0) / 0.15, 0.0, 1.0) * step(r, 1.0) * pow(lobe, 2.0);
      col += vec3(0.25) * min(glow, 1.0);
      gl_FragColor = vec4(col, 1.0);
      return;
    }
  }
  gl_FragColor = vec4(shade(p), 1.0);
}`,n=`
precision highp float;
varying vec2 vUV;
varying vec2 uRes;
varying vec3 uBg, uAnchor, uC0, uC1, uC2;
varying float uPhase, uAudio, uSpin, uArch, uTime;
`+a+`
void main() {
  gl_FragColor = vec4(shade(vUV * 2.0 - 1.0), 1.0);
}`,o=`
attribute vec2 aPos;
attribute vec2 aUV;
attribute vec4 iPos;  // cellX, cellY, sizePx, spin
attribute vec4 iDyn;  // audio, phase, arch, time
attribute vec4 iBg;   // bg.rgb, anchor.r
attribute vec4 iAnc;  // anchor.gb, c0.rg
attribute vec4 iC0b;  // c0.b, c1.rgb
attribute vec4 iC2;   // c2.rgb, _
uniform vec2 uCanvas; // atlas size in device px
varying vec2 vUV;
varying vec2 uRes;
varying vec3 uBg, uAnchor, uC0, uC1, uC2;
varying float uPhase, uAudio, uSpin, uArch, uTime;
void main() {
  vUV = aUV;
  uSpin = iPos.w;
  uAudio = iDyn.x;
  uPhase = iDyn.y;
  uArch = iDyn.z;
  uTime = iDyn.w;
  uRes = vec2(iPos.z);
  uBg = iBg.rgb;
  uAnchor = vec3(iBg.a, iAnc.x, iAnc.y);
  uC0 = vec3(iAnc.z, iAnc.w, iC0b.x);
  uC1 = iC0b.yzw;
  uC2 = iC2.xyz;
  vec2 pPx = iPos.xy + aUV * iPos.z;          // top-down px within the cell
  float ndcX = pPx.x / uCanvas.x * 2.0 - 1.0;
  float ndcY = 1.0 - pPx.y / uCanvas.y * 2.0; // flip to GL y-up
  gl_Position = vec4(ndcX, ndcY, 0.0, 1.0);
}`;function i(e,t,a){let r=e.createShader(t);return r?(e.shaderSource(r,a),e.compileShader(r),e.getShaderParameter(r,e.COMPILE_STATUS))?r:(console.error("[AgentOrb] shader compile failed:",e.getShaderInfoLog(r)),e.deleteShader(r),null):null}let s=["uRes","uBg","uAnchor","uC0","uC1","uC2","uTime","uPhase","uAudio","uSpin","uArch","uLens"],l=0,c=new Map;function u(e,t){let a=null===e.lastT?0:Math.min(.1,Math.max(0,t-e.lastT));e.lastT=t;let r=Math.max(l,c.get(e.seed)??0),n=r>e.audioSmooth?.11:.3;e.audioSmooth+=(r-e.audioSmooth)*(a>0?1-Math.exp(-a/n):0);let o=r>e.audioFast?.04:.18;e.audioFast+=(r-e.audioFast)*(a>0?1-Math.exp(-a/o):0);let i=6.31*e.phase%1,s=.35*Math.sin(t*(.11+.08*(2.17*e.phase%1))+e.phase),u=e.audioFast,d=Math.sin(t*(.45+.2*i)+e.phase);Math.sign(d)!==e.oscSign&&(e.oscSign=Math.sign(d),e.flipQueued=!0),e.flipQueued&&u<.18&&(e.spinDir=-e.spinDir,e.flipQueued=!1);let h=.65*(.65+.7*i)*(1+s)+e.spinDir*u*2.2;e.spinVel+=(h-e.spinVel)*(a>0?1-Math.exp(-a/.35):0);let f=Math.max(0,u-e.prevA);e.prevA=u,e.spinVel+=e.spinDir*Math.min(6*f,1.4)*a*14,e.spin+=e.spinVel*a}class d{canvas;gl;ext;prog=null;ready=!1;uCanvas=null;instBuffer=null;data=new Float32Array(24576);constructor(e,t,a){this.canvas=e,this.gl=t,this.ext=a,this.init()}init(){let e=this.gl,t=i(e,e.VERTEX_SHADER,o),a=i(e,e.FRAGMENT_SHADER,n);if(!t||!a)return;let r=e.createProgram();if(!r)return;if(e.attachShader(r,t),e.attachShader(r,a),e.bindAttribLocation(r,0,"aPos"),e.bindAttribLocation(r,1,"aUV"),e.bindAttribLocation(r,2,"iPos"),e.bindAttribLocation(r,3,"iDyn"),e.bindAttribLocation(r,4,"iBg"),e.bindAttribLocation(r,5,"iAnc"),e.bindAttribLocation(r,6,"iC0b"),e.bindAttribLocation(r,7,"iC2"),e.linkProgram(r),e.deleteShader(t),e.deleteShader(a),!e.getProgramParameter(r,e.LINK_STATUS))return void console.error("[AgentOrb] instanced link failed:",e.getProgramInfoLog(r));this.prog=r,this.uCanvas=e.getUniformLocation(r,"uCanvas");let s=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,s),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,0,1,1,-1,1,1,-1,1,0,0,1,1,1,0]),e.STATIC_DRAW),e.enableVertexAttribArray(0),e.vertexAttribPointer(0,2,e.FLOAT,!1,16,0),e.enableVertexAttribArray(1),e.vertexAttribPointer(1,2,e.FLOAT,!1,16,8),this.instBuffer=e.createBuffer(),e.bindBuffer(e.ARRAY_BUFFER,this.instBuffer),e.bufferData(e.ARRAY_BUFFER,this.data.byteLength,e.DYNAMIC_DRAW);for(let t=0;t<6;t++){let a=2+t;e.enableVertexAttribArray(a),e.vertexAttribPointer(a,4,e.FLOAT,!1,96,16*t),this.ext.vertexAttribDivisorANGLE(a,1)}e.enable(e.BLEND),e.blendFunc(e.ONE,e.ONE_MINUS_SRC_ALPHA),this.ready=!0}writeInstance(e,t,a,r,n,o){let i=24*e,s=this.data;s[i]=t,s[i+1]=a,s[i+2]=r,s[i+3]=n.spin,s[i+4]=n.audioSmooth,s[i+5]=n.phase,s[i+6]=n.arch,s[i+7]=o,s[i+8]=n.bg[0],s[i+9]=n.bg[1],s[i+10]=n.bg[2],s[i+11]=n.anchor[0],s[i+12]=n.anchor[1],s[i+13]=n.anchor[2],s[i+14]=n.accents[0][0],s[i+15]=n.accents[0][1],s[i+16]=n.accents[0][2],s[i+17]=n.accents[1][0],s[i+18]=n.accents[1][1],s[i+19]=n.accents[1][2],s[i+20]=n.accents[2][0],s[i+21]=n.accents[2][1],s[i+22]=n.accents[2][2],s[i+23]=0}renderGroup(e,t){if(!this.ready||!this.prog)return!1;let a=this.gl,r=Math.max(1,Math.floor(this.canvas.width/t)),n=Math.min(r*Math.max(1,Math.floor(this.canvas.height/t)),1024);a.useProgram(this.prog),a.uniform2f(this.uCanvas,this.canvas.width,this.canvas.height),a.viewport(0,0,this.canvas.width,this.canvas.height),a.bindBuffer(a.ARRAY_BUFFER,this.instBuffer);for(let o=0;o<e.length;o+=n){let i=Math.min(n,e.length-o);for(let a=0;a<i;a++){let n=e[o+a];u(n.spec,n.animT);let i=a%r,s=Math.floor(a/r);this.writeInstance(a,i*t,s*t,t,n.spec,n.animT)}a.bufferSubData(a.ARRAY_BUFFER,0,this.data.subarray(0,24*i)),a.clearColor(0,0,0,0),a.clear(a.COLOR_BUFFER_BIT),this.ext.drawArraysInstancedANGLE(a.TRIANGLE_STRIP,0,4,i);for(let a=0;a<i;a++){let n=e[o+a],i=a%r,s=Math.floor(a/r);n.ctx.drawImage(this.canvas,i*t,s*t,t,t,0,0,t,t)}}return!0}}e.s(["BATCH_MAX_PX",0,512,"FRAME_MS",0,1e3/60,"GL_CONTEXT_OPTS",0,{premultipliedAlpha:!0,alpha:!0,antialias:!0,preserveDrawingBuffer:!0},"MAX_DPR",0,2,"MAX_PX",0,1280,"OrbBatchRenderer",0,d,"OrbRenderer",0,class{gl;prog=null;u=null;ready=!1;canvas;constructor(e,t){this.canvas=e,this.gl=t,e.addEventListener("webglcontextlost",e=>{e.preventDefault(),this.ready=!1}),e.addEventListener("webglcontextrestored",()=>this.init()),this.init()}init(){let e=this.gl,a=i(e,e.VERTEX_SHADER,t),n=i(e,e.FRAGMENT_SHADER,r);if(!a||!n)return;let o=e.createProgram();if(!o||(e.attachShader(o,a),e.attachShader(o,n),e.bindAttribLocation(o,0,"aPos"),e.bindAttribLocation(o,1,"aUV"),e.linkProgram(o),e.deleteShader(a),e.deleteShader(n),!e.getProgramParameter(o,e.LINK_STATUS)))return;this.prog=o;let l={};for(let t of s)l[t]=e.getUniformLocation(o,t);this.u=l;let c=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,c),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,0,1,1,-1,1,1,-1,1,0,0,1,1,1,0]),e.STATIC_DRAW),e.enableVertexAttribArray(0),e.vertexAttribPointer(0,2,e.FLOAT,!1,16,0),e.enableVertexAttribArray(1),e.vertexAttribPointer(1,2,e.FLOAT,!1,16,8),e.enable(e.BLEND),e.blendFunc(e.ONE,e.ONE_MINUS_SRC_ALPHA),e.enable(e.SCISSOR_TEST),this.ready=!0}render(e,t,a){if(!this.ready||!this.prog||!this.u)return!1;let r=this.gl;r.useProgram(this.prog);let n=this.canvas.height-t;r.viewport(0,n,t,t),r.scissor(0,n,t,t);let o=this.u;return r.uniform2f(o.uRes,t,t),r.uniform3f(o.uBg,e.bg[0],e.bg[1],e.bg[2]),r.uniform3f(o.uAnchor,e.anchor[0],e.anchor[1],e.anchor[2]),r.uniform3f(o.uC0,...e.accents[0]),r.uniform3f(o.uC1,...e.accents[1]),r.uniform3f(o.uC2,...e.accents[2]),r.uniform1f(o.uTime,a),r.uniform1f(o.uPhase,e.phase),r.uniform1f(o.uArch,e.arch),r.uniform1f(o.uLens,e.lens),u(e,a),r.uniform1f(o.uAudio,e.audioSmooth),r.uniform1f(o.uSpin,e.spin),r.clearColor(0,0,0,0),r.clear(r.COLOR_BUFFER_BIT),r.drawArrays(r.TRIANGLE_STRIP,0,4),!0}},"advanceAnimT",0,function(e,t){let a=null===e.lastNow?0:Math.min(100,Math.max(0,t-e.lastNow));e.animT+=a/1e3,e.lastNow=t},"hashSeed",0,function(e){let t=0x811c9dc5;for(let a=0;a<e.length;a++)t^=e.charCodeAt(a),t=Math.imul(t,0x1000193);return t>>>0},"setCoreAudioLevel",0,function(e,t){void 0!==t?null===e?c.delete(t):c.set(t,Math.min(1,Math.max(0,e))):l=null===e?0:Math.min(1,Math.max(0,e))},"toRGB",0,e=>[parseInt(e.slice(1,3),16)/255,parseInt(e.slice(3,5),16)/255,parseInt(e.slice(5,7),16)/255]])},7510914,e=>{"use strict";e.s(["default",0,function(t,a){return(r,n)=>(function(t,a,r,n){let o="SharedWorker"===t.name,i=e.b,s=[r.map(t=>e.h("string"==typeof t?t:t.path,i)).reverse(),e.X,i],l=["NEXT_DEPLOYMENT_ID","NEXT_CLIENT_ASSET_SUFFIX"];for(let e=0;e<l.length;e++)s.push(globalThis[l[e]]);let c=new URL(e.h(a,i),location.origin),u=JSON.stringify(s);return o?c.searchParams.set("params",u):c.hash="#params="+encodeURIComponent(u),new t(c,n?{...n,type:void 0}:void 0)})(r,t,a,n)}])}]);

//# debugId=add5c52e-4906-9ba1-ae0b-b5f3c6b6ebed